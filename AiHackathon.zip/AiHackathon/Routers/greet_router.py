


from State.HelpDeskState import HelpDeskState


def route_after_greeting(state: HelpDeskState):
    """Check if the greeting node wants to hand over to RAG."""
    generation = state.get("generation", "")
    
    if "TRANSITION_TO_RAG" in generation:
        # User asked a tech question, send them to the RAG pipeline
        # (Change this to "category_classifier_node" if you still want to classify the DB/Network first)
        return "retrieve_node" 
        
    # Otherwise, it was just a greeting, go to memory as usual
    return "remember_node"