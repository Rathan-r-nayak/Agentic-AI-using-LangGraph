from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables.config import RunnableConfig
from langchain_core.messages import AIMessage # 🚨 ADD THIS
from Config.LLMConfig import fast_llm
from State.HelpDeskState import HelpDeskState
from Utils.DatabaseManager import get_user_facts
from Utils.Helpers import format_chat_history

def greeting_node(state: HelpDeskState, config: RunnableConfig):
    print("--- HANDLING GREETING VIA LLM ---")
    question = state.get("question", "")
    print(question)
    
    # 1. Fetch LONG-TERM memory
    user_id = config["configurable"].get("thread_id", "default_user")
    long_term_facts = get_user_facts(user_id)
    
    # We pull existing messages from state
    messages = state.get("messages", [])
    stm_history = format_chat_history(messages)

    print("-------------------------------------------")
    print(long_term_facts if long_term_facts else "No known facts about user.")
    print("-------------------------------------------")
    
    # 2. Personalized Prompt
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are a polite AI Helpdesk Assistant. 
        
        TASK:
        - If the user is greeting you or asking who they are, respond warmly using the 'Facts' below.
        - If the user is asking a technical IT question (e.g. "How do I...", "Fix my...", "What is..."), respond EXACTLY with: TRANSITION_TO_RAG
        
        Facts you know about this user:
        {long_term_facts}
        
        Recent Chat (Short-Term): 
        {stm_history}
        """),
        ("human", "{question}")
    ])
    
    chain = prompt | fast_llm  
    response = chain.invoke({
        "long_term_facts": long_term_facts, 
        "question": question,
        "stm_history": stm_history
    })
    
    # 🚨 THE CRITICAL CHANGE: 
    # We must return BOTH the generation string (for routing) 
    # AND the new AIMessage (so the messages list isn't empty later).
    
    new_message = AIMessage(content=response.content)
    
    return {
        "generation": response.content,
        "messages": [new_message] # This triggers the Annotated reducer in HelpDeskState
    }