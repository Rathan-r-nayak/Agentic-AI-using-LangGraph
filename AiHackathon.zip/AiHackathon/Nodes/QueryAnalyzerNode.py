from Config.LLMConfig import fast_llm
from Schema.QueryAnalysis import QueryAnalysis
from State.HelpDeskState import HelpDeskState
from langchain_core.prompts import ChatPromptTemplate

def query_analyzer_node(state: HelpDeskState):
    print("--- ANALYZING & REWRITING QUERY ---")
    
    structured_llm = fast_llm.with_structured_output(QueryAnalysis)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are an IT Helpdesk Query Optimizer. 
        Your job is to read the user's technical issue, classify its category, 
        identify the specific application, and rewrite the query to be used in a Vector Database search.
        
        Focus the search query purely on technical keywords, error codes, and system behaviors.
        Do not assess urgency, impact, or classify the user's state. Keep the focus strictly on the technical architecture."""),
        ("human", "{question}")
    ])
    
    chain = prompt | structured_llm
    
    # Using try-except here is a good safety net for lab environments
    try:
        analysis = chain.invoke({"question": state["question"]})
        
        print(f"-> Category: {analysis.category}")
        # print(f"-> App: {analysis.application_name}")
        print(f"-> Search Query: {analysis.optimized_search_query}")
        
        return {
            "category": analysis.category,
            # "application_name": analysis.application_name,
            "search_query": analysis.optimized_search_query
        }
    except Exception as e:
        print(f"-> Error in Analyzer: {e}")
        # Fallback to the raw question if the filter still triggers
        return {
            "category": "General",
            # "application_name": "None",
            "search_query": state["question"]
        }