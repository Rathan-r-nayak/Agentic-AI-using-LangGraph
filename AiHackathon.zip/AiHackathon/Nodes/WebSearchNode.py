from State.HelpDeskState import HelpDeskState
from langchain_community.utilities import DuckDuckGoSearchAPIWrapper

def web_search_node(state: HelpDeskState):
    print("--- 🌐 EXECUTING WEB SEARCH (DuckDuckGo) ---")
    
    # Check the Human-in-the-loop flag
    approved = state.get("web_search_approved", True) 
    
    if not approved:
        print("-> Web Search denied by user. Proceeding to Orchestrator.")
        return {} # State remains unchanged

    # Use the optimized query if available, otherwise the raw question
    search_query = state.get("search_query") or state.get("question")
    print(f"-> Searching web for: {search_query}")
    
    try:
        # Initialize the wrapper to pull the top 3 results
        ddg = DuckDuckGoSearchAPIWrapper(max_results=3)
        
        # This returns a list of dicts: [{'title': '...', 'snippet': '...', 'link': '...'}]
        results = ddg.results(search_query, max_results=3)
        
        web_docs = []
        for r in results:
            web_docs.append({
                "content": r.get("snippet", ""),
                "metadata": {
                    "category": "Web Search", 
                    "source": r.get("link", "web"),
                    "title": r.get("title", "Unknown")
                }
            })
            
    except Exception as e:
        print(f"-> DuckDuckGo Search Failed: {e}")
        web_docs = []

    # Append the new web docs to the existing internal docs
    existing_docs = state.get("documents", [])
    existing_docs.extend(web_docs)
    
    print(f"-> Added {len(web_docs)} web documents to context.")
    return {"documents": existing_docs}