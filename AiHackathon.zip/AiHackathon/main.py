import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.constants import Send
from langgraph.checkpoint.memory import MemorySaver

# 1. Import State & Utilities
from State.HelpDeskState import HelpDeskState
from Utils.Helpers import format_chat_history

# 2. Import All Nodes
from Nodes.GreetingNode import greeting_node
from Nodes.QueryAnalyzerNode import query_analyzer_node
from Nodes.RetrieveNode import retrieve_node
from Nodes.EvaluatorNode import evaluator_node
from Nodes.WebSearchNode import web_search_node
from Nodes.OrchestratorNode import orchestrator_node
from Nodes.WorkerNode import worker_node
from Nodes.MergeNode import merge_node
from Nodes.CritiqueNode import critique_node
from Nodes.RememberNode import remember_node
# Ensure you import your router if you want to use the JSON-based routing
# from Nodes.IntentRouterNode import intent_router_node 

# ==========================================
# ROUTING LOGIC FUNCTIONS
# ==========================================

def route_after_greeting(state: HelpDeskState):
    generation = state.get("generation", "")
    # Failsafe: if the LLM mentions technical terms but forgets the trigger
    if "TRANSITION_TO_RAG" in generation or "database" in generation.lower() or "error" in generation.lower():
        return "query_analyzer_node"
    return "remember_node"

def route_after_evaluation(state: HelpDeskState):
    if state.get("is_sufficient"):
        return "orchestrator_node"
    return "web_search_node"

def distribute_tasks(state: HelpDeskState):
    """
    MAP: This sends tasks to parallel worker_nodes
    """
    ltm = state.get("long_term_facts", "")
    # Ensure stm is a string for the worker prompts
    stm = format_chat_history(state.get("messages", []))
    
    return [
        Send("worker_node", {
            "task": t, 
            "documents": state.get("documents", []),
            "question": state["question"],
            "long_term_facts": ltm,
            "chat_history": stm
        }) for t in state.get("tasks", [])
    ]



# ==========================================
# BUILD THE GRAPH
# ==========================================

print("--- ⚙️ COMPILING HELPDESK CHAT WORKFLOW ---")

workflow = StateGraph(HelpDeskState)

# --- Add All Nodes ---
workflow.add_node("greeting_node", greeting_node)
workflow.add_node("query_analyzer_node", query_analyzer_node)
workflow.add_node("retrieve_node", retrieve_node)
workflow.add_node("evaluator_node", evaluator_node)
workflow.add_node("web_search_node", web_search_node)
workflow.add_node("orchestrator_node", orchestrator_node)
workflow.add_node("worker_node", worker_node)
workflow.add_node("merge_node", merge_node)
workflow.add_node("critique_node", critique_node)
workflow.add_node("remember_node", remember_node)

# --- Define Logic Flow ---

# 1. Start Path
workflow.add_edge(START, "greeting_node")

# 2. Greeting -> RAG Pipeline or Remember/End
workflow.add_conditional_edges(
    "greeting_node",
    route_after_greeting,
    {
        "query_analyzer_node": "query_analyzer_node",
        "remember_node": "remember_node"
    }
)

# 3. Retrieval & Evaluation
workflow.add_edge("query_analyzer_node", "retrieve_node")
workflow.add_edge("retrieve_node", "evaluator_node")

workflow.add_conditional_edges(
    "evaluator_node",
    route_after_evaluation,
    {
        "orchestrator_node": "orchestrator_node",
        "web_search_node": "web_search_node"
    }
)

# Web Search leads back to Orchestrator
workflow.add_edge("web_search_node", "orchestrator_node")

# 4. Parallel Workers (Map-Reduce)
# The "Map" step
workflow.add_conditional_edges(
    "orchestrator_node",
    distribute_tasks,
    ["worker_node"]
)

# The "Reduce" step: All workers automatically flow into merge_node 
# once they have all finished their parallel execution.
workflow.add_edge("worker_node", "merge_node")

# 5. Cleanup & Safety
workflow.add_edge("merge_node", "critique_node")
workflow.add_edge("critique_node", "remember_node")
workflow.add_edge("remember_node", END)

# ==========================================
# COMPILE WITH CHECKPOINTER
# ==========================================

# Using MemorySaver for current session history
memory = MemorySaver()

app = workflow.compile(
    checkpointer=memory,
    interrupt_before=["web_search_node"]
)

print("--- ✅ GRAPH COMPILED SUCCESSFULLY ---")