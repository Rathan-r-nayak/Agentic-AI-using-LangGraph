from pydantic import BaseModel, Field

class QueryAnalysis(BaseModel):
    category: str = Field(
        description="The technical domain of the issue (e.g., Database, Network, Software, Hardware)."
    )
    application_name: str = Field(
        description="The specific application experiencing the issue, or 'None' if unknown."
    )
    optimized_search_query: str = Field(
        description="A rewritten search string focusing purely on error codes and technical indicators."
    )